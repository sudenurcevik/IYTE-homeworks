DROP TABLE BELONGS CASCADE CONSTRAINTS;
DROP TABLE PRESCRIPTED_DRUG CASCADE CONSTRAINTS;
DROP TABLE SOLDDRUG CASCADE CONSTRAINTS;
DROP TABLE PRESCRIPTION CASCADE CONSTRAINTS;
DROP TABLE DOCTOR CASCADE CONSTRAINTS;
DROP TABLE SUPPLIES CASCADE CONSTRAINTS;
DROP TABLE STOCKITEM;
DROP TABLE MAKES CASCADE CONSTRAINTS;
DROP TABLE SALE CASCADE CONSTRAINTS;
DROP TABLE EMPLOYEE CASCADE CONSTRAINTS;
DROP TABLE PATIENT CASCADE CONSTRAINTS;
DROP TABLE PERSON;
DROP TABLE SUPPLIER;
DROP TABLE DRUG;


CREATE TABLE PERSON(
    personID INT NOT NULL,
    phoneNumber VARCHAR2(13),
    birthDate DATE,
    personName VARCHAR2(40) NOT NULL,
    gender VARCHAR2(5),
    CONSTRAINT person_personID_pk PRIMARY KEY(personID)
);

CREATE TABLE DOCTOR (
    personID INT NOT NULL,
    workplace VARCHAR2(40),
    branchName VARCHAR2(100),
    CONSTRAINT doctor_personID_pk PRIMARY KEY(personID),
    CONSTRAINT doctor_personID_fk FOREIGN KEY (personID) REFERENCES PERSON(personID) ON DELETE CASCADE 
);

CREATE TABLE EMPLOYEE(
    personID INT NOT NULL,
    salary FLOAT NOT NULL,
    title VARCHAR2(40) NOT NULL,
    startDateOfEmployement DATE,
    street VARCHAR2(30),
    apartmentNo VARCHAR2(7),
    city VARCHAR2(30),
    country VARCHAR2(30),
    CONSTRAINT employee_salary_ck CHECK(salary > 0),
    CONSTRAINT employee_personID_pk PRIMARY KEY(personID),
    CONSTRAINT employee_person_fk FOREIGN KEY (personID) REFERENCES PERSON(personID) ON DELETE CASCADE
);


CREATE TABLE PATIENT(
    personID INT NOT NULL,
    insuranceInfo VARCHAR2(100),
    CONSTRAINT patient_personID_pk PRIMARY KEY(personID),
    CONSTRAINT patient_person_fk FOREIGN KEY (personID) REFERENCES PERSON(personID)  ON DELETE CASCADE
);

CREATE TABLE PRESCRIPTION(
    prescriptionID INT NOT NULL,
    prescriptionType VARCHAR2(15),
    expireDate DATE,
    docID INT NOT NULL,
    CONSTRAINT prescription_prescriptionID_pk PRIMARY KEY(prescriptionID),
    CONSTRAINT prescription_doctor_fk FOREIGN KEY (docID) REFERENCES DOCTOR(personID) ON DELETE CASCADE
);

CREATE TABLE SALE(
    saleID INT NOT NULL,
    saleDate DATE NOT NULL,
    totalPrice FLOAT,
    personID INT NOT NULL,
    CONSTRAINT sale_saleID_pk PRIMARY KEY(saleID),
    CONSTRAINT sale_person_fk FOREIGN KEY (personID) REFERENCES PATIENT(personID) ON DELETE SET NULL
);

CREATE TABLE DRUG(
    drugID INT NOT NULL,
    drugName VARCHAR2(40) NOT NULL,
    drugForm VARCHAR2(20) NOT NULL,
    drugEffectGroup VARCHAR2(35),
    drugDosage VARCHAR2(25) NOT NULL,
    drugPrice FLOAT NOT NULL,
    supplyPrice FLOAT NOT NULL,
    expireDate DATE NOT NULL,
    CONSTRAINT drug_drugID_pk PRIMARY KEY(drugID),
    CONSTRAINT drug_drugID_ck CHECK(drugID > 0),
    CONSTRAINT drug_drugPrice_ck CHECK(drugPrice > 0),
    CONSTRAINT drug_supplyPrice_ck CHECK(supplyPrice > 0)
);

CREATE TABLE PRESCRIPTED_DRUG(
    drugID INT NOT NULL,
    usageAmount SMALLINT NOT NULL,
    usageWay VARCHAR2(20) NOT NULL,
    prescriptionDescription VARCHAR2(100),
    usageDosage FLOAT NOT NULL,
    usagePeriod SMALLINT NOT NULL,
    drugQuantity SMALLINT NOT NULL,
    prescriptionID INT NOT NULL,
    CONSTRAINT prescripted_drug_drugID_pk PRIMARY KEY(drugID),
    CONSTRAINT prescripted_drug_drug_fk FOREIGN KEY (drugID) REFERENCES DRUG(drugID)  ON DELETE CASCADE,
    CONSTRAINT prescripted_drug_prescription_fk FOREIGN KEY (prescriptionID) REFERENCES PRESCRIPTION(prescriptionID)  ON DELETE CASCADE
);

CREATE TABLE SOLDDRUG(
    drugID INT NOT NULL,
    drugAmount SMALLINT NOT NULL,
    saleID INT NOT NULL,
    CONSTRAINT sold_drug_drugID_pk PRIMARY KEY(drugID),
    CONSTRAINT sold_drug_drugAmount_ck CHECK(drugAmount > 0),
    CONSTRAINT sold_drug_drug_fk FOREIGN KEY (drugID) REFERENCES DRUG(drugID)  ON DELETE CASCADE,
    CONSTRAINT sold_drug_sale_fk FOREIGN KEY (saleID) REFERENCES SALE(saleID)  ON DELETE CASCADE 
);


CREATE TABLE SUPPLIER(
    supplierID INT NOT NULL,
    supplierName VARCHAR2(100) NOT NULL,
    phoneNumber VARCHAR2(13),
    street VARCHAR2(50),
    apartmentNo VARCHAR2(15),
    city VARCHAR2(30),
    country VARCHAR2(30),
    CONSTRAINT supplier_supplierID_pk PRIMARY KEY(supplierID),
    CONSTRAINT supplier_supplierName_uk UNIQUE (supplierName)
);

CREATE TABLE STOCKITEM(
    stockItemID INT NOT NULL,
    shelfNo INT,
    stockAmount INT NOT NULL,
    drugID INT NOT NULL,
    CONSTRAINT stockitem_stockAmount_ck CHECK(stockAmount > 0),
    CONSTRAINT stockitem_stockitemID_pk PRIMARY KEY(stockItemID),
    CONSTRAINT stockitem_drugID_fk FOREIGN KEY(drugId) REFERENCES DRUG(drugID)   ON DELETE CASCADE
);


CREATE TABLE SUPPLIES(
    drugID INT NOT NULL,
    supplierID INT NOT NULL,
    CONSTRAINT supplies_drug_fk FOREIGN KEY (drugID) REFERENCES DRUG(drugID)                 ON DELETE CASCADE,
    CONSTRAINT supplies_supplier_fk FOREIGN KEY (supplierID) REFERENCES SUPPLIER(supplierID) ON DELETE CASCADE,
    CONSTRAINT supplies_drugID_supplierID_pk PRIMARY KEY(drugID, supplierID)        
);



CREATE TABLE MAKES(
    personID INT NOT NULL,
    saleID INT NOT NULL,
    CONSTRAINT makes_person_fk FOREIGN KEY (personID) REFERENCES EMPLOYEE(personID)  ON DELETE SET NULL,
    CONSTRAINT makes_sale_fk FOREIGN KEY (saleID) REFERENCES SALE(saleID)            ON DELETE CASCADE,
    CONSTRAINT makes_saleID_pk PRIMARY KEY (saleID)
);


CREATE TABLE BELONGS(
    personID INT NOT NULL,
    prescriptionID INT NOT NULL,
    CONSTRAINT belongs_person_fk FOREIGN KEY (personID) REFERENCES PATIENT(personID) ON DELETE CASCADE,
    CONSTRAINT belongs_prescription_fk FOREIGN KEY (prescriptionID) REFERENCES PRESCRIPTION(prescriptionID) ON DELETE CASCADE,
    CONSTRAINT belongs_prescriptionID_pk PRIMARY KEY (prescriptionID)
);


CREATE OR REPLACE TRIGGER check_birthdate
BEFORE INSERT OR UPDATE ON PERSON
FOR EACH ROW
BEGIN
   IF :new.birthDate > SYSDATE THEN
      RAISE_APPLICATION_ERROR(-20001, 'Birthdate cannot be in the future');
   END IF;
END;
/

CREATE OR REPLACE TRIGGER sale_amount_check
BEFORE INSERT OR UPDATE ON SOLDDRUG
FOR EACH ROW
DECLARE
stock NUMBER;
BEGIN
    SELECT stockAmount INTO stock FROM STOCKITEM WHERE drugID=:new.drugID;
    IF (:new.drugAmount > stock) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Stock is not enough for that drug');
    END IF;
END;
/

CREATE OR REPLACE TRIGGER sale_is_made
AFTER INSERT ON SOLDDRUG
FOR EACH ROW
BEGIN
    UPDATE STOCKITEM
    SET stockAmount = stockAmount - :new.drugAmount
    WHERE drugID=:new.drugID;
  
    UPDATE SALE
    SET totalPrice = totalPrice + (:new.drugAmount * (SELECT drugPrice FROM DRUG WHERE drugID = :new.drugID))
    WHERE saleID= :new.saleID;
END;
/


INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678901, '123-456-7891', '01-01-1991', 'John Smith', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789002, '234-567-8902', '02-02-1990', 'Jane Doe', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890123, '345-678-9013', '03-03-1989', 'Robert Johnson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901234, '456-789-0124', '04-04-1988', 'Samantha Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012345, '567-890-1235', '05-05-1987', 'Michael Brown', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123456, '678-901-2346', '06-06-1986', 'Emily Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234567, '789-012-3457', '07-07-1985', 'William Thompson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345678, '890-123-4568', '08-08-1984', 'Ashley Johnson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456789, '901-234-5679', '09-09-1983', 'David Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567890, '012-345-6780', '10-10-1982', 'Jessica Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678902, '123-456-7892', '11-11-1981', 'James Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789013, '234-567-8903', '12-12-1980', 'Emily Thompson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890124, '345-678-9014', '01-01-1980', 'William Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901235, '456-789-0125', '02-02-1979', 'Ashley Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012346, '567-890-1236', '03-03-1978', 'David Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123457, '678-901-2347', '04-04-1977', 'Jessica Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234568, '789-012-3459', '05-05-1976', 'James Davis', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345679, '890-123-4560', '06-06-1975', 'Emily Anderson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456780, '901-234-5671', '07-07-1974', 'William Williams', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567892, '012-345-6782', '08-08-1973', 'Ashley Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678903, '123-456-7893', '09-09-1972', 'David Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789014, '234-567-8904', '10-10-1971', 'Jessica Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890125, '345-678-9015', '11-11-1970', 'James Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901236, '456-789-0126', '12-12-1969', 'Emily Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012347, '567-890-1237', '01-01-1969', 'William Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123458, '678-901-2348', '02-02-1968', 'Ashley Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234569, '789-012-3459', '03-03-1967', 'David Davis', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345670, '890-123-4561', '04-04-1966', 'Jessica Anderson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456782, '901-234-5678', '05-05-1965', 'James Williams', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567893, '012-345-6783', '06-06-1964', 'Emily Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678904, '123-456-7894', '07-07-1963', 'William Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789015, '234-567-8905', '08-08-1962', 'Ashley Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890126, '345-678-9016', '09-09-1961', 'David Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901237, '456-789-0127', '10-10-1960', 'Jessica Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012348, '567-890-1238', '11-11-1959', 'James Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123459, '678-901-2349', '12-12-1958', 'Emily Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234560, '789-012-3450', '01-01-1958', 'William Davis', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345672, '890-123-4562', '02-02-1957', 'Ashley Anderson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456783, '901-234-5673', '03-03-1956', 'David Williams', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567894, '012-345-6784', '04-04-1955', 'Jessica Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678905, '223-456-7890', '05-05-1954', 'James Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789016, '334-567-8901', '06-06-1953', 'Emily Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890127, '445-678-9012', '07-07-1952', 'William Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901238, '556-789-0123', '08-08-1951', 'Ashley Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012349, '667-890-1234', '09-09-1950', 'David Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123450, '778-901-2345', '10-10-1949', 'Jessica Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234562, '889-012-3456', '11-11-1948', 'James Davis', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345673, '990-123-4567', '12-12-1947', 'Emily Anderson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456787, '911-234-5678', '01-01-1947', 'William Williams', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567895, '022-345-6789', '02-02-1946', 'Ashley Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678906, '133-456-7890', '03-03-1945', 'David Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789017, '244-567-8901', '04-04-1944', 'Jessica Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890128, '355-678-9012', '05-05-1943', 'James Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901239, '466-789-0123', '06-06-1942', 'Emily Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012340, '577-890-1234', '07-07-1941', 'William Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123452, '688-901-2345', '08-08-1940', 'Ashley Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234563, '799-012-3456', '09-09-1939', 'David Davis', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (89012345674, '800-123-4567', '10-10-1938', 'Jessica Anderson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (90123456785, '901-334-5678', '11-11-1937', 'James Williams', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (01234567896, '012-445-6789', '12-12-1936', 'Emily Taylor', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (12345678907, '123-556-7890', '01-01-1936', 'William Jackson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (23456789018, '234-667-8901', '02-02-1935', 'Ashley Davis', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (34567890129, '345-778-9012', '03-03-1934', 'David Anderson', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (45678901230, '456-889-0123', '04-04-1933', 'Jessica Williams', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (56789012342, '567-890-1234', '05-05-1932', 'James Taylor', 'M'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (67890123453, '678-991-2345', '06-06-1931', 'Emily Jackson', 'F'); 

INSERT INTO PERSON (personID, phoneNumber, birthDate, personName, gender) VALUES (78901234564, '789-011-3456', '07-07-1930', 'William Davis', 'M'); 

  

-----------------------------------------------------------PERSON INSERTION--------------------------------------------------------------------------------- 

  

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (12345678901, 'Central Hospital', 'Cardiology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (23456789002, 'City Clinic', 'General Practice'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (34567890123, 'Community Health Center', 'Pediatrics'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (45678901234, 'Regional Hospital', 'Surgery'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (56789012345, 'Private Practice', 'Dermatology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (67890123456, 'County Hospital', 'Obstetrics and Gynecology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (78901234567, 'Childrens Hospital', 'Oncology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (89012345678, 'State University Hospital', 'Anesthesiology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (90123456789, 'Veterans Affairs Medical Center', 'Psychiatry'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (01234567890, 'Private Clinic', 'Ophthalmology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (12345678902, 'Community Health Center', 'Physical Medicine and Rehabilitation'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (23456789013, 'Regional Hospital', 'Neurology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (34567890124, 'City Clinic', 'Endocrinology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (45678901235, 'Private Practice', 'Rheumatology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (56789012346, 'County Hospital', 'Allergy and Immunology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (67890123457, 'Childrens Hospital', 'Pulmonology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (78901234568, 'State University Hospital', 'Gastroenterology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (89012345679, 'Veterans Affairs Medical Center', 'Hematology'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (90123456780, 'Private Clinic', 'Infectious Disease'); 

INSERT INTO DOCTOR (personID, workplace, branchName) VALUES (01234567892, 'Community Health Center', 'Geriatrics'); 


-------------------------------------------------------DOCTOR INSERTION---------------------------------------------------------------- 



INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (12345678903, 65000, 'Pharmacist', '05-25-2022', 'Main St', '1A', 'New York', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (23456789014, 50000, 'Pharmacy Technician', '09-23-2022', 'Second Ave', '2B', 'Chicago', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (34567890125, 55000, 'Assistant Pharmacist', '12-09-2020', 'Third St', '3C', 'Los Angeles', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (45678901236, 60000, 'Pharmacy Manager', '11-20-2021', 'Fourth Ave', '4D', 'Houston', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (56789012347, 70000, 'Pharmacist', '10-12-2020', 'Fifth St', '5E', 'Philadelphia', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (67890123458, 45000, 'Pharmacy Technician', '03-21-2021', 'Sixth Ave', '6F', 'Phoenix', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (78901234569, 50000, 'Assistant Pharmacist', '05-24-2022', 'Seventh St', '7G', 'San Antonio', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (89012345670, 60000, 'Pharmacy Manager', '03-07-2021', 'Eighth Ave', '8H', 'San Diego', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (90123456782, 65000, 'Pharmacist', '02-02-2021', 'Ninth St', '9I', 'Dallas', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (01234567893, 50000, 'Pharmacy Technician', '09-01-2021', 'Tenth Ave', '10J', 'San Jose', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (12345678904, 55000, 'Assistant Pharmacist', '03-13-2021', 'Eleventh St', '11K', 'Austin', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (23456789015, 60000, 'Pharmacy Manager', '09-01-2021', 'Twelfth Ave', '12L', 'Jacksonville', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (34567890126, 70000, 'Pharmacist', '11-09-2020', 'Thirteenth St', '13M', 'Indianapolis', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (45678901237, 45000, 'Pharmacy Technician', '09-15-2020', 'Fourteenth Ave', '14N', 'San Francisco', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (56789012348, 50000, 'Assistant Pharmacist', '09-29-2021', 'Fifteenth St', '15O', 'Columbus', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (67890123459, 60000, 'Pharmacy Manager', '07-30-2022', 'Sixteenth Ave', '16P', 'Charlotte', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (78901234560, 65000, 'Pharmacist', '08-02-2021', 'Seventeenth St', '17Q', 'Fort Worth', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (89012345672, 50000, 'Pharmacy Technician', '08-23-2021', 'Eighteenth Ave', '18R', 'Detroit', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (90123456783, 55000, 'Assistant Pharmacist', '08-04-2021', 'Nineteenth St', '19S', 'El Paso', 'USA'); 

INSERT INTO EMPLOYEE (personID, salary, title, startDateOfEmployement, street, apartmentNo, city, country) VALUES (01234567894, 60000, 'Pharmacy Manager', '08-22-2022', 'Twentieth Ave', '20T', 'Memphis', 'USA'); 


--------------------------------------------------------EMPLOYEE INSERTON----------------------------------------------------------------------- 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (89012345673, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (90123456787, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (01234567895, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (12345678906, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (23456789017, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (34567890128, 'SGK'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (45678901239, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (56789012340, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (67890123452, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (78901234563, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (89012345674, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (90123456785, 'Private Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (01234567896, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (12345678907, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (23456789018, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (34567890129, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (45678901230, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (56789012342, 'Military Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (67890123453, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (78901234564, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (12345678905, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (23456789016, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (34567890127, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (45678901238, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (56789012349, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (67890123450, 'Retirement Insurance'); 

INSERT INTO PATIENT (personID, insuranceInfo) VALUES (78901234568, 'Retirement Insurance'); 

 

-------------------------------------------------------PATIENT INSERTION------------------------------------------------------------------ 


INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (1, 'Ibuprofen', 'Tablet', 'Pain Relief', '200mg', 10.99, 5.50, '01-24-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (2, 'Acetaminophen', 'Capsule', 'Pain Relief', '500mg', 7.49, 3.75, '04-22-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (3, 'Amoxicillin', 'Capsule', 'Antibiotic', '250mg', 13.99, 7.00, '08-29-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (4, 'Metformin', 'Tablet', 'Diabetes', '500mg', 19.99, 9.50, '08-26-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (5, 'Lisinopril', 'Tablet', 'High Blood Pressure', '10mg', 22.49, 11.25, '06-20-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (6, 'Zoloft', 'Tablet', 'Antidepressant', '50mg', 32.99, 16.50, '05-02-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (7, 'Claritin', 'Tablet', 'Allergy', '10mg', 18.99, 9.50, '03-30-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (8, 'Aspirin', 'Tablet', 'Pain Relief', '325mg', 9.99, 5.00, '03-21-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (9, 'Lipitor', 'Tablet', 'High Cholesterol', '20mg', 44.99, 22.50, '12-25-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (10, 'Paroxetine', 'Tablet', 'Antidepressant', '20mg', 104.99, 52.50, '05-28-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (11, 'Singulair', 'Tablet', 'Asthma', '10mg', 49.99, 25.00, '11-15-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (12, 'Nexium', 'Capsule', 'Acid Reflux', '40mg', 42.99, 21.50, '11-17-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (13, 'Celebrex', 'Capsule', 'Arthritis', '200mg', 59.99, 30.00, '02-28-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (14, 'Crestor', 'Tablet', 'High Cholesterol', '10mg', 69.99, 35.00, '10-25-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (15, 'Allegra', 'Tablet', 'Allergy', '180mg', 34.99, 17.50, '12-11-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (16, 'Ventolin', 'Inhaler', 'Asthma', '90mcg', 39.99, 20.00, '04-22-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (17, 'Advair', 'Inhaler', 'Asthma', '100/50mcg', 89.99, 45.00, '09-20-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (18, 'Plavix', 'Tablet', 'Blood Thinner', '75mg', 84.99, 42.50, '05-01-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (19, 'Zyrtec', 'Tablet', 'Allergy', '10mg', 24.99, 12.50, '11-22-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (20, 'Mirtazapine', 'Tablet', 'Antidepressant', '15mg', 99.99, 50.00, '07-15-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (21, 'Xanax', 'Tablet', 'Anxiety', '0.25mg', 29.99, 15.00, '04-11-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (22, 'Synthroid', 'Tablet', 'Thyroid', '100mcg', 44.99, 22.50, '04-17-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (23, 'Valsartan', 'Tablet', 'High Blood Pressure', '160mg', 19.99, 10.00, '06-27-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (24, 'Desvenlafaxine', 'Tablet', 'Antidepressant', '50mg', 79.99, 40.00, '06-10-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (25, 'Duloxetine', 'Capsule', 'Antidepressant', '60mg', 84.99, 42.50, '03-24-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (26, 'Escitalopram', 'Tablet', 'Antidepressant', '10mg', 89.99, 45.00, '11-04-2022'); 
  
INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (27, 'Omeprazole', 'Capsule', 'Acid Reflux', '20mg', 24.99, 12.50, '06-30-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (28, 'Pravastatin', 'Tablet', 'High Cholesterol', '40mg', 29.99, 15.00, '09-29-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (29, 'Lexapro', 'Tablet', 'Antidepressant', '10mg', 34.99, 17.50, '08-08-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (30, 'Phentermine', 'Capsule', 'Weight Loss', '37.5mg', 39.99, 20.00, '12-27-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (31, 'Trazodone', 'Tablet', 'Antidepressant', '50mg', 44.99, 22.50, '03-16-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (32, 'Metoprolol', 'Tablet', 'High Blood Pressure', '25mg', 49.99, 25.00, '06-05-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (33, 'Propranolol', 'Tablet', 'High Blood Pressure', '10mg', 54.99, 27.50, '08-28-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (34, 'Atorvastatin', 'Tablet', 'High Cholesterol', '20mg', 59.99, 30.00, '07-25-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (35, 'Zaldiar', 'Capsule', 'Antidepressant', '20mg', 97.99, 49.50, '04-15-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (36, 'Clonazepam', 'Tablet', 'Anxiety', '0.5mg', 64.99, 32.50, '06-27-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (37, 'Venlafaxine', 'Tablet', 'Antidepressant', '75mg', 69.99, 35.00, '07-11-2022'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (38, 'Amitriptyline', 'Tablet', 'Antidepressant', '25mg', 74.99, 37.50, '09-01-2023'); 

INSERT INTO DRUG (drugID, drugName, drugForm, drugEffectGroup, drugDosage, drugPrice, supplyPrice, expireDate) VALUES (39, 'Fluoxetine', 'Capsule', 'Antidepressant', '20mg', 94.99, 47.50, '04-17-2023'); 


  

  

-----------------------------------------------DRUG INSERTION-------------------------------------------------------------------------------- 

  

  

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (1, 1, 50, 1); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (2, 2, 75, 2); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (3, 3, 100, 3); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (4, 4, 125, 4); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (5, 5, 150, 5); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (6, 6, 175, 6); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (7, 7, 200, 7); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (8, 8, 225, 8); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (9, 9, 250, 9); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (10, 10, 275, 10); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (11, 11, 300, 11); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (12, 12, 325, 12); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (13, 13, 350, 13); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (14, 14, 375, 14); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (15, 15, 400, 15); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (16, 1, 425, 16); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (17, 2, 450, 17); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (18, 3, 475, 18); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (19, 4, 500, 19); 

INSERT INTO STOCKITEM (stockItemID, shelfNo, stockAmount, drugID) VALUES (20, 5, 525, 20); 

  

------------------------------STOCK ITEM INSERTION--------------------------------------------------------------------------- 

  

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (1, '10-21-2022', 0,34567890128); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (2, '02-18-2022', 0,45678901239); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (3, '02-01-2022', 0,56789012340); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (4, '01-10-2022', 0,67890123452); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (5, '12-05-2022', 0,78901234563); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (6, '05-15-2022', 0,89012345674); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (7, '01-15-2021', 0,90123456785); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (8, '09-08-2021', 0,01234567896); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (9, '10-29-2021', 0,12345678907); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (10, '12-02-2022', 0,23456789018); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (11, '05-15-2022', 0, 34567890129); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (12, '12-09-2022', 0, 45678901230); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (13, '03-25-2022', 0, 56789012342); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (14, '11-11-2021', 0, 67890123453); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (15, '04-06-2022', 0, 78901234564); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (16, '12-19-2021', 0, 12345678905); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (17, '05-20-2022', 0, 23456789016); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (18, '06-29-2022', 0, 34567890127); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (19, '02-22-2022', 0, 45678901238); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (20, '11-25-2021', 0, 56789012349); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (21, '10-27-2022', 0, 67890123450); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (22, '01-25-2022', 0, 78901234568); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (23, '12-25-2021', 0, 89012345673); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (24, '09-30-2021', 0, 90123456787); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (25, '05-07-2021', 0, 01234567895); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (26, '07-05-2022', 0, 12345678906); 

INSERT INTO SALE (saleID, saleDate, totalPrice, personID) VALUES (27, '05-22-2021', 0, 23456789017); 
 

  

--------------------------------------SALE INSERTION--------------------------------------------------------- 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (1, 5, 1); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (2, 1, 2); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (3, 5, 3); 


INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (4, 2, 4); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (5, 2, 5); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (6, 3, 6); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (7, 3, 7); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (8, 4, 8); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (9, 4, 9); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (10, 5, 10); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (11, 5, 11); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (12, 6, 12); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (13, 5, 13); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (14, 7, 14); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (15, 7, 15); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (16, 8, 16); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (17, 8, 17); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (18, 9, 18); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (19, 9, 19); 

INSERT INTO SOLDDRUG (drugID, drugAmount, saleID) VALUES (20, 10, 20); 
  

----------------------------------SOLD DRUG INSERTION------------------------------------------ 


  

INSERT INTO MAKES (personID, saleID) VALUES (12345678903, 1); 

INSERT INTO MAKES (personID, saleID) VALUES (23456789014, 2); 

INSERT INTO MAKES (personID, saleID) VALUES (34567890125, 3); 

INSERT INTO MAKES (personID, saleID) VALUES (45678901236, 4); 

INSERT INTO MAKES (personID, saleID) VALUES (56789012347, 5); 

INSERT INTO MAKES (personID, saleID) VALUES (67890123458, 6); 

INSERT INTO MAKES (personID, saleID) VALUES (78901234569, 7); 

INSERT INTO MAKES (personID, saleID) VALUES (89012345670, 8); 

INSERT INTO MAKES (personID, saleID) VALUES (90123456782, 9); 

INSERT INTO MAKES (personID, saleID) VALUES (01234567893, 10); 

INSERT INTO MAKES (personID, saleID) VALUES (12345678904, 11); 

INSERT INTO MAKES (personID, saleID) VALUES (23456789015, 12); 

INSERT INTO MAKES (personID, saleID) VALUES (34567890126, 13); 

INSERT INTO MAKES (personID, saleID) VALUES (45678901237, 14); 

INSERT INTO MAKES (personID, saleID) VALUES (56789012348, 15); 

INSERT INTO MAKES (personID, saleID) VALUES (67890123459, 16); 

INSERT INTO MAKES (personID, saleID) VALUES (78901234560, 17); 

INSERT INTO MAKES (personID, saleID) VALUES (89012345672, 18); 

INSERT INTO MAKES (personID, saleID) VALUES (90123456783, 19); 

INSERT INTO MAKES (personID, saleID) VALUES (01234567894, 20); 


-----------------------------------------------------------MAKES------------------------------------------------------------------ 

  

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (1, 'Özel Reçete', '06-15-2022', 12345678901); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (2, 'Özel Reçete', '01-08-2023', 23456789002); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (3, 'Özel Reçete', '07-12-2022', 34567890123 ); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (4, 'Özel Reçete', '01-05-2022', 45678901234); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (5, 'Özel Reçete', '10-27-2023',56789012345); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (6, 'Özel Reçete', '06-19-2022', 67890123456); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (7, 'Özel Reçete', '10-05-2023', 78901234567); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (8, 'Özel Reçete', '01-03-2022', 89012345678); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (9, 'Özel Reçete', '03-03-2022', 90123456789); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (10, 'Özel Reçete', '02-11-2022', 01234567890); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (11, 'Özel Reçete', '11-04-2022', 12345678902); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (12, 'Özel Reçete', '10-16-2023', 23456789013); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (13, 'Özel Reçete', '10-02-2022', 34567890124 ); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (14, 'Özel Reçete', '09-27-2023', 45678901235); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (15, 'Özel Reçete', '10-18-2022', 56789012346); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (16, 'Özel Reçete', '04-17-2023', 67890123457); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (17, 'Özel Reçete', '02-27-2023', 78901234568); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (18, 'Özel Reçete', '10-19-2023', 89012345679); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (19, 'Özel Reçete', '10-19-2023', 90123456780); 

INSERT INTO PRESCRIPTION (prescriptionID, prescriptionType, expireDate, docID) VALUES (20, 'Özel Reçete', '06-05-2023', 01234567892); 

----------------------------------------------PRESCRIPTION---------------------------------------------------------------- 

  

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (1, 1, 'Oral', 'Take 1 tablet twice a day', 0.5, 10, 2, 1); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (2, 1, 'Injection', 'Administer 1 injection every other day', 1, 14, 7, 2); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (3, 1, 'Topical', 'Apply 1 mL of ointment to affected area twice a day', 1, 30, 30, 3); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (4, 1, 'Oral', 'Take 1 capsule once a day', 1, 30, 20, 4); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (5, 2, 'Oral', 'Take 2 capsules once a day', 1, 30, 10, 5); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (7, 1, 'Topical', 'Apply 1 mL of ointment to affected area twice a day', 1, 30, 20, 6); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (6, 6, 'Oral', 'Take 3 capsules twice a day', 2, 30, 5, 7); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (8, 1, 'Injection', 'Administer 1 injection every other day', 3, 14, 2, 8); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (9, 1, 'Oral', 'Take 1 capsule once a day', 1, 10, 2, 9); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (10, 1, 'Topical', 'Apply 5 mL of ointment to affected area twice a day', 1, 30, 1, 10); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (11, 6, 'Oral', 'Take 3 capsules twice a day', 1, 30, 20, 11); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (12, 2, 'Oral', 'Take 1 capsule twicea day', 1, 30, 3, 12); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (13, 4, 'Oral', 'Take 2 capsules twice a day', 1, 30, 3, 13); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (14, 1, 'Topical', 'Apply 2 mL of ointment to affected area twice a day', 1, 15, 1, 14); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (15, 2, 'Oral', 'Take 1 capsule twice a day', 1, 10, 1 , 15); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (16, 2, 'Oral', 'Take 1 capsule twice a day', 1, 20, 2, 16); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (17, 2, 'Oral', 'Take 2 capsules once a day', 1, 30, 5, 17); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (18, 3, 'Oral', 'Take 1 capsule three times a day', 1, 30, 2, 18); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (19, 1, 'Oral', 'Take 1 capsule once a day', 1, 20, 2, 19); 

INSERT INTO PRESCRIPTED_DRUG (drugID, usageAmount, usageWay, prescriptionDescription, usageDosage, usagePeriod, drugQuantity, prescriptionID) VALUES (20, 2, 'Oral', 'Take 2 capsules once a day', 1, 30, 4, 20); 

 

-----------------------------------------------PRESCRIPTED DRUG--------------------------------------------------------- 

 
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 1, 'Pfizer PFE İlaçları Anonim Şirketi', '212-310-7000', 'Büyükdere Caddesi', '12', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 2, 'Novartis Sağlık, Gıda ve Tarım Ürünleri San. ve Tic. A.Ş.', '216- 681-2000', 'Şehit Sinan Eroğlu Cad.', '6', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 3, 'Abbvie Tıbbi İlaçlar San. ve Tic. Ltd. Şti.', '216-636-06-00', 'Büyükdeniz Cad.', '2','istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 4, 'Apotex İlaç San. ve Tic. Ltd. Şti.', '212-320-7500', 'Muhtarbey Sok.', '14','istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 5, 'Casel İlaç San. Tic. Ltd. Şti.', '212-310-7909', 'Nadide Caddesi', '5', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 6, 'CENOVA SAĞLIK ÜRÜNLERİ SAN. ve TİC. A.Ş.', '282-310-7077', 'Ayazağa Ticaret Merkezi','4' , 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 7, 'Deva Holding A.Ş.', '212-170-5000', 'Basın Ekspress Caddesi', '1', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 8, 'Eczacıbaşı İlaç Pazarlama A.Ş.', '214-310-7000', 'Büyükdere Caddesi', '5', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 9, 'Eczacıbaşı-Zentiva Sağlık Ürünleri San. ve Tic. A.Ş.', '212-310-7002', 'Büyükdere Caddesi', '12', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 10, 'Genzyme Sağlık Hizmetleri ve Tedavi Ürünleri Tic. Ltd. Şti.', '212-980-5670', 'Muhittin Üstündağ Cad.', '13', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 11, 'Gripin İlaç A.Ş.', '212-310-7090', 'Grip Caddesi', '44', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 12, 'Koçak Farma İlaç ve Kimya Sanayi A.Ş.', '212-890-7005', 'Bağlarbaşı Gazi Caddesi', '61', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 13, 'Koz İlaç San. ve Tic. A.Ş.', '216-310-6900', 'Büyükdere Caddesi', '82', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 14, 'Mefar İlaç Sanayii A.Ş.', '212-670-7000', 'Ensar Caddesi', '2', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 15, 'Nobel Sağlık Ürünleri Ltd. Şti.', '216-633-60-00', 'Akçaokça Caddesi', '12', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 16, 'Novartis Sağlık Gıda ve Tarım Ürünleri San. Tic. A.Ş.', '212-681-2000', 'Sinan Eroğlu Cad', '6', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 17, 'Palmiye İlaç Kimya ve Gıda San. Tic. Ltd. Şti', '212-367-7800', 'Sinop Caddesi', '22', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 18, 'RDC İlaç Araştırma ve Geliştirme A.Ş', '212-310-4090', 'Gersan Caddesi', '12', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 19, 'Sandoz İlaç San. ve Tic. A.Ş.', '212-570-9500', ' Şakir Elkovan Cad.', '1', 'istanbul','Turkey');
INSERT INTO SUPPLIER (supplierID, supplierName, phoneNumber, street, apartmentNo, city, country) VALUES ( 20, 'Zentiva Sağlık Ürünleri San. ve Tic. A.Ş.', '212-390-7550', 'Büyükdere Caddesi', '7', 'istanbul','Turkey');

------------------------------------------------------------------SUPPLIER---------------------------------------------------------------


INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (89012345673, 1); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (90123456787, 2);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (01234567895, 3); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (12345678906, 4); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (23456789017, 5); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (34567890128, 6);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (45678901239, 7);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (56789012340, 8);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (67890123452, 9);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (78901234563, 10); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (89012345674, 11);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (90123456785, 12);
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (01234567896, 13); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (12345678907, 14); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (23456789018, 15); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (34567890129, 16); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (45678901230, 17); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (56789012342, 18); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (67890123453, 19); 
INSERT INTO BELONGS (personID, PrescriptionID)  VALUES (78901234564, 20); 

-----------------------------------------------------------------BELONGS---------------------------------------------------------------------


INSERT INTO SUPPLIES (drugID, supplierID) VALUES (1, 1);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (2, 2);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (3, 3);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (4, 4);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (5, 5);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (6, 6);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (7, 7);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (8, 8);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (9, 9);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (10, 10);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (11, 11);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (12, 12);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (13, 13);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (14, 14);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (15, 15);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (16, 16);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (17, 17);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (18, 18);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (19, 19);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (20, 20);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (21, 1);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (22, 2);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (23, 3);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (24, 4);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (25, 5);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (26, 6);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (27, 7);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (28, 8);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (29, 9);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (30, 10);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (31, 11);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (32, 12);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (33, 13);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (34, 14);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (35, 15);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (36, 16);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (37, 17);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (38, 18);
INSERT INTO SUPPLIES (drugID, supplierID) VALUES (39, 19);
